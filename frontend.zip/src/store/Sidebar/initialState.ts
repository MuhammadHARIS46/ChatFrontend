export interface SidebarInterface {
  sidebar: boolean;
}
export const initialState: SidebarInterface = {
  sidebar: false,
};
